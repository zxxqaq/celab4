#pragma once


#include "semihost.h"


void __mem_alloc_init_all();